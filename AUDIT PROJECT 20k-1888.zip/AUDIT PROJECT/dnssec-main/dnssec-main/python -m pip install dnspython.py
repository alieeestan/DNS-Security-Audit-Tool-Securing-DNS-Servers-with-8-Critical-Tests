python --version

